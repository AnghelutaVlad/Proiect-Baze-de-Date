﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AplicatieCabinetVeterinar
{
    internal class Animale_cu_afectiuni
    {

        public int AnimalID { get; set; }

        public int AfectiuneID { get; set; }

        public DateTime DataDiagnostic { get; set; }

        public string Stare { get; set; }

    }
}
