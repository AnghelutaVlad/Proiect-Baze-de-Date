﻿namespace AplicatieCabinetVeterinar
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            dataGridView1 = new DataGridView();
            groupBox1 = new GroupBox();
            txt_specializare = new TextBox();
            txt_datanastere = new TextBox();
            txt_oras = new TextBox();
            txt_adresa = new TextBox();
            txt_email = new TextBox();
            txt_telefon = new TextBox();
            txt_cnp = new TextBox();
            txt_prenume = new TextBox();
            txt_nume = new TextBox();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(29, 406);
            button1.Name = "button1";
            button1.Size = new Size(96, 23);
            button1.TabIndex = 0;
            button1.Text = "Adaugă";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(323, 56);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(395, 301);
            dataGridView1.TabIndex = 1;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(txt_specializare);
            groupBox1.Controls.Add(txt_datanastere);
            groupBox1.Controls.Add(txt_oras);
            groupBox1.Controls.Add(txt_adresa);
            groupBox1.Controls.Add(txt_email);
            groupBox1.Controls.Add(txt_telefon);
            groupBox1.Controls.Add(txt_cnp);
            groupBox1.Controls.Add(txt_prenume);
            groupBox1.Controls.Add(txt_nume);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(21, 56);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(282, 317);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "Veterinar";
            // 
            // txt_specializare
            // 
            txt_specializare.Location = new Point(99, 286);
            txt_specializare.Name = "txt_specializare";
            txt_specializare.Size = new Size(100, 23);
            txt_specializare.TabIndex = 17;
            // 
            // txt_datanastere
            // 
            txt_datanastere.Location = new Point(99, 252);
            txt_datanastere.Name = "txt_datanastere";
            txt_datanastere.Size = new Size(100, 23);
            txt_datanastere.TabIndex = 16;
            // 
            // txt_oras
            // 
            txt_oras.Location = new Point(99, 218);
            txt_oras.Name = "txt_oras";
            txt_oras.Size = new Size(100, 23);
            txt_oras.TabIndex = 15;
            // 
            // txt_adresa
            // 
            txt_adresa.Location = new Point(99, 187);
            txt_adresa.Name = "txt_adresa";
            txt_adresa.Size = new Size(100, 23);
            txt_adresa.TabIndex = 14;
            // 
            // txt_email
            // 
            txt_email.Location = new Point(99, 153);
            txt_email.Name = "txt_email";
            txt_email.Size = new Size(100, 23);
            txt_email.TabIndex = 13;
            // 
            // txt_telefon
            // 
            txt_telefon.Location = new Point(99, 120);
            txt_telefon.Name = "txt_telefon";
            txt_telefon.Size = new Size(100, 23);
            txt_telefon.TabIndex = 12;
            // 
            // txt_cnp
            // 
            txt_cnp.Location = new Point(99, 82);
            txt_cnp.Name = "txt_cnp";
            txt_cnp.Size = new Size(100, 23);
            txt_cnp.TabIndex = 11;
            // 
            // txt_prenume
            // 
            txt_prenume.Location = new Point(99, 51);
            txt_prenume.Name = "txt_prenume";
            txt_prenume.Size = new Size(100, 23);
            txt_prenume.TabIndex = 10;
            // 
            // txt_nume
            // 
            txt_nume.Location = new Point(99, 21);
            txt_nume.Name = "txt_nume";
            txt_nume.Size = new Size(133, 23);
            txt_nume.TabIndex = 9;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(6, 286);
            label9.Name = "label9";
            label9.Size = new Size(68, 15);
            label9.TabIndex = 8;
            label9.Text = "Specializare";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(6, 252);
            label8.Name = "label8";
            label8.Size = new Size(74, 15);
            label8.TabIndex = 7;
            label8.Text = "Data Naștere";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(6, 218);
            label7.Name = "label7";
            label7.Size = new Size(31, 15);
            label7.TabIndex = 6;
            label7.Text = "Oraș";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(6, 187);
            label6.Name = "label6";
            label6.Size = new Size(43, 15);
            label6.TabIndex = 5;
            label6.Text = "Adresă";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(6, 153);
            label5.Name = "label5";
            label5.Size = new Size(36, 15);
            label5.TabIndex = 4;
            label5.Text = "Email";
            label5.Click += label5_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 120);
            label4.Name = "label4";
            label4.Size = new Size(45, 15);
            label4.TabIndex = 3;
            label4.Text = "Telefon";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 82);
            label3.Name = "label3";
            label3.Size = new Size(31, 15);
            label3.TabIndex = 2;
            label3.Text = "CNP";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 51);
            label2.Name = "label2";
            label2.Size = new Size(55, 15);
            label2.TabIndex = 1;
            label2.Text = "Prenume";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 21);
            label1.Name = "label1";
            label1.Size = new Size(40, 15);
            label1.TabIndex = 0;
            label1.Text = "Nume\r\n";
            label1.Click += label1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(555, 406);
            button2.Name = "button2";
            button2.Size = new Size(90, 23);
            button2.TabIndex = 3;
            button2.Text = "Reîncarcă";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(194, 406);
            button3.Name = "button3";
            button3.Size = new Size(95, 23);
            button3.TabIndex = 4;
            button3.Text = "Update";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(375, 406);
            button4.Name = "button4";
            button4.Size = new Size(90, 23);
            button4.TabIndex = 5;
            button4.Text = "Șterge";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(groupBox1);
            Controls.Add(dataGridView1);
            Controls.Add(button1);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button button1;
        private DataGridView dataGridView1;
        private GroupBox groupBox1;
        private Label label1;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private TextBox txt_cnp;
        private TextBox txt_prenume;
        private TextBox txt_nume;
        private TextBox txt_specializare;
        private TextBox txt_datanastere;
        private TextBox txt_oras;
        private TextBox txt_adresa;
        private TextBox txt_email;
        private TextBox txt_telefon;
        private Button button2;
        private Button button3;
        private Button button4;
    }
}