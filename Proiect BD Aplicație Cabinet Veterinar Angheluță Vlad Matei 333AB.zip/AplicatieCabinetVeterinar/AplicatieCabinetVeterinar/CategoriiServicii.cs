﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AplicatieCabinetVeterinar
{
    internal class CategoriiServicii
    {
        public int ID { get; set; }

        public string Denumire { get; set; }

        public string Detalii { get; set; }
    }
}
