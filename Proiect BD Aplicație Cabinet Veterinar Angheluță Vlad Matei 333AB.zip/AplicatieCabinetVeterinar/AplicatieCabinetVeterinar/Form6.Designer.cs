﻿namespace AplicatieCabinetVeterinar
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            label1 = new Label();
            button1 = new Button();
            comboBox1 = new ComboBox();
            label2 = new Label();
            button2 = new Button();
            dataGridView2 = new DataGridView();
            txt_begin = new TextBox();
            txt_end = new TextBox();
            label3 = new Label();
            label4 = new Label();
            button3 = new Button();
            dataGridView3 = new DataGridView();
            dataGridView4 = new DataGridView();
            label5 = new Label();
            label6 = new Label();
            dataGridView5 = new DataGridView();
            label7 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView5).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(416, 224);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(318, 205);
            dataGridView1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(416, 154);
            label1.Name = "label1";
            label1.Size = new Size(230, 21);
            label1.TabIndex = 1;
            label1.Text = "Cele mai recente diagnostice";
            // 
            // button1
            // 
            button1.Location = new Point(416, 191);
            button1.Name = "button1";
            button1.Size = new Size(133, 23);
            button1.TabIndex = 2;
            button1.Text = "Afișare diagnostice recente";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Vindecat", "Nevindecat" });
            comboBox1.Location = new Point(61, 209);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(121, 23);
            comboBox1.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(61, 173);
            label2.Name = "label2";
            label2.Size = new Size(125, 21);
            label2.TabIndex = 4;
            label2.Text = "Status Animale";
            // 
            // button2
            // 
            button2.Location = new Point(61, 250);
            button2.Name = "button2";
            button2.Size = new Size(244, 23);
            button2.TabIndex = 5;
            button2.Text = "Afișare animale cu status-ul selectat";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(61, 279);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.Size = new Size(300, 150);
            dataGridView2.TabIndex = 6;
            // 
            // txt_begin
            // 
            txt_begin.Location = new Point(907, 138);
            txt_begin.Name = "txt_begin";
            txt_begin.Size = new Size(100, 23);
            txt_begin.TabIndex = 7;
            // 
            // txt_end
            // 
            txt_end.Location = new Point(907, 197);
            txt_end.Name = "txt_end";
            txt_end.Size = new Size(100, 23);
            txt_end.TabIndex = 8;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(907, 111);
            label3.Name = "label3";
            label3.Size = new Size(78, 15);
            label3.TabIndex = 9;
            label3.Text = "De la data de:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(907, 173);
            label4.Name = "label4";
            label4.Size = new Size(93, 15);
            label4.TabIndex = 10;
            label4.Text = "Până la data de: ";
            // 
            // button3
            // 
            button3.Location = new Point(907, 238);
            button3.Name = "button3";
            button3.Size = new Size(115, 23);
            button3.TabIndex = 11;
            button3.Text = "Afișează consultații ";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // dataGridView3
            // 
            dataGridView3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView3.Location = new Point(907, 279);
            dataGridView3.Name = "dataGridView3";
            dataGridView3.Size = new Size(382, 213);
            dataGridView3.TabIndex = 12;
            // 
            // dataGridView4
            // 
            dataGridView4.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView4.Location = new Point(61, 556);
            dataGridView4.Name = "dataGridView4";
            dataGridView4.Size = new Size(544, 214);
            dataGridView4.TabIndex = 13;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(61, 524);
            label5.Name = "label5";
            label5.Size = new Size(122, 21);
            label5.TabIndex = 14;
            label5.Text = "Detalii Servicii";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(907, 73);
            label6.Name = "label6";
            label6.Size = new Size(285, 30);
            label6.TabIndex = 15;
            label6.Text = "Consultații dintr-o perioadă";
            // 
            // dataGridView5
            // 
            dataGridView5.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView5.Location = new Point(760, 556);
            dataGridView5.Name = "dataGridView5";
            dataGridView5.Size = new Size(393, 187);
            dataGridView5.TabIndex = 16;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(758, 518);
            label7.Name = "label7";
            label7.Size = new Size(313, 21);
            label7.TabIndex = 17;
            label7.Text = "Cele mai populare servicii per categorie";
            // 
            // Form6
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1330, 817);
            Controls.Add(label7);
            Controls.Add(dataGridView5);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(dataGridView4);
            Controls.Add(dataGridView3);
            Controls.Add(button3);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(txt_end);
            Controls.Add(txt_begin);
            Controls.Add(dataGridView2);
            Controls.Add(button2);
            Controls.Add(label2);
            Controls.Add(comboBox1);
            Controls.Add(button1);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            Name = "Form6";
            Text = "Form6";
            Load += Form6_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView4).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Label label1;
        private Button button1;
        private ComboBox comboBox1;
        private Label label2;
        private Button button2;
        private DataGridView dataGridView2;
        private TextBox txt_begin;
        private TextBox txt_end;
        private Label label3;
        private Label label4;
        private Button button3;
        private DataGridView dataGridView3;
        private DataGridView dataGridView4;
        private Label label5;
        private Label label6;
        private DataGridView dataGridView5;
        private Label label7;
    }
}