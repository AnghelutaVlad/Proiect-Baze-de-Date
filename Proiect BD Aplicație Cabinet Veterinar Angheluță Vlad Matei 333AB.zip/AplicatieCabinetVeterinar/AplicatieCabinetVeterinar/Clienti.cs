﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AplicatieCabinetVeterinar
{
    internal class Clienti
    {
        //public int ID { get; set; }

        public string Nume { get; set; }

        public string Prenume { get; set; }

        public string CNP { get; set; }

        public string Telefon { get; set; }

        public string Email { get; set; }

        public string Adresă { get; set; }

        public string Oraș { get; set; }

        public DateTime DataNașterii { get; set; }
    }
}
