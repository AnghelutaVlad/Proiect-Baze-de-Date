﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AplicatieCabinetVeterinar
{
    internal class Afectiune
    {
        public  int ID { get; set; }

        public string Denumire { get; set; }
        
        public string Simptome { get; set; }

        public string Recomandare {  get; set; }
    }
}
