﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AplicatieCabinetVeterinar
{
    internal class Review
    {
        public int ConsultatieID { get; set; }

        public int ClientID {  get; set; }

        public int Scor {  get; set; }

        public string Recenzie {  get; set; }
    }
}
